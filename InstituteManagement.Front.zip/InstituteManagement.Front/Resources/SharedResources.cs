﻿namespace InstituteManagement.Front.Resources
{
    public class SharedResources
    {
    }
}
